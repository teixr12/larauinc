'use client'

import Image from 'next/image'
import { useInView } from './useInView'
import SunIcon from './SunIcon'

const heritageItems = [
  {
    id: 1,
    image: 'https://framerusercontent.com/images/GZVYEmsDNEO9wXq3AiFTxIdHwQ.png',
    label: 'Culture'
  },
  {
    id: 2,
    image: 'https://framerusercontent.com/images/F1mgfSrmJqHPR0N41EW5JirkM.png',
    label: 'Heritage'
  },
  {
    id: 3,
    image: 'https://framerusercontent.com/images/kIvmrhbi4eBaxvjTLRQJ6lCA.png',
    label: 'Moment'
  },
  {
    id: 4,
    image: 'https://framerusercontent.com/images/NWDud2T3bGlKl242xbPpCWH06Ms.png',
    label: 'Presence'
  }
]

export default function Heritage() {
  const { ref, isInView } = useInView({ threshold: 0.1 })

  return (
    <section className="heritage-section" id="heritage" ref={ref}>
      <div className="heritage-header">
        <h2 
          className="heritage-title"
          style={{
            clipPath: isInView ? 'inset(0 0% 0 0)' : 'inset(0 100% 0 0)',
            transition: 'clip-path 1s cubic-bezier(0.77, 0, 0.175, 1)',
          }}
        >
          heritage
        </h2>
        
        <p 
          className={`heritage-text transition-all duration-700 ${
            isInView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
          }`}
          style={{ transitionDelay: '0.3s' }}
        >
          each ardène residence is more than a home. it is a dialogue between landscape, architecture, and light — designed to belong, to endure, to inspire
        </p>
      </div>

      <div className="heritage-grid">
        {heritageItems.map((item, index) => (
          <div 
            key={item.id}
            className={`heritage-item transition-all duration-700 ${
              isInView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
            }`}
            style={{ transitionDelay: `${0.1 + index * 0.1}s` }}
          >
            <Image
              src={item.image}
              alt={item.label}
              fill
              className="heritage-image"
              sizes="(max-width: 768px) 100vw, 25vw"
            />
            <span className="heritage-label">{item.label}</span>
          </div>
        ))}
        
        {/* Brand Card */}
        <div 
          className={`heritage-item heritage-brand transition-all duration-700 ${
            isInView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
          }`}
          style={{ transitionDelay: '0.5s' }}
        >
          <SunIcon size={24} color="#121212" />
          <span className="heritage-brand-text">Ardène Residence</span>
        </div>
      </div>
    </section>
  )
}
