'use client'

import Image from 'next/image'
import { useInView } from './useInView'
import SunIcon from './SunIcon'

const projects = [
  {
    id: 1,
    name: 'villa\nlumière',
    location: 'Provence',
    year: '2025',
    coords: '43.7031° N,\n5.4500° E',
    architect: 'Jean-Pierre Lefèvre',
    architectImage: 'https://framerusercontent.com/images/LxSXimjlPkiCARezsTFekUrXo.png',
    description: 'a secluded villa surrounded by vineyards and olive trees. expansive windows, natural textures, a horizon that never ends',
    image: 'https://framerusercontent.com/images/ZSpVyvz66B4hQs2QXi0QtLp0tXw.png',
    prefix: 'Designed by:'
  },
  {
    id: 2,
    name: 'villa\nsolenne',
    location: "Côte d'Azur",
    year: '2025',
    coords: '43.5528° N,\n7.0174° E',
    architect: 'Claire Moreau',
    architectImage: 'https://framerusercontent.com/images/9GpmqBk4XDWOKe9Fr5jSGJK4jOU.png',
    description: 'a coastal villa where the sea and sky merge. terraces bathed in mediterranean light, serene interiors, and the calm of endless horizons',
    image: 'https://framerusercontent.com/images/8XwAz6kOwW2XBWbuGMv2Trqqe80.png',
    prefix: 'Designed by:'
  },
  {
    id: 3,
    name: 'maison\nélysée',
    location: "Côte d'Azur",
    year: '2025',
    coords: '43.5510° N,\n7.0174° E',
    architect: 'Camille Rousseau',
    architectImage: 'https://framerusercontent.com/images/CDWDEe6rgB07RDMHeDWvUur4mXY.png',
    description: 'an intimate mediterranean retreat. sunlit terraces, citrus gardens, and the stillness of water — a house of quiet presence',
    image: 'https://framerusercontent.com/images/rj3mXwHoxkCcSw9HmyNr8bP7e80.png',
    prefix: 'Architecture by:'
  }
]

export default function Residences() {
  const { ref, isInView } = useInView({ threshold: 0.1 })

  return (
    <>
      {/* Ceramic Image */}
      <div className="full-image-section">
        <Image
          src="https://framerusercontent.com/images/24NpEk4VYis880amUJ0BVpEFmBc.png"
          alt="Ceramic vase"
          width={1600}
          height={900}
          className="full-image"
        />
      </div>

      <section className="residences-section" id="residences" ref={ref}>
        <h2 
          className={`residences-title`}
          style={{
            clipPath: isInView ? 'inset(0 0% 0 0)' : 'inset(0 100% 0 0)',
            transition: 'clip-path 1s cubic-bezier(0.77, 0, 0.175, 1)',
          }}
        >
          residences
        </h2>
        
        <div 
          className={`residences-meta transition-all duration-700 ${
            isInView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
          }`}
          style={{ transitionDelay: '0.3s' }}
        >
          <SunIcon size={20} color="#121212" />
          <span className="residences-collection">Collection I — France</span>
        </div>

        {/* Projects */}
        {projects.map((project, index) => (
          <ProjectCard key={project.id} project={project} delay={index * 0.2} />
        ))}

        <a href="#" className="see-more">see more</a>
      </section>
    </>
  )
}

function ProjectCard({ project, delay }: { project: typeof projects[0], delay: number }) {
  const { ref, isInView } = useInView({ threshold: 0.2 })

  return (
    <article 
      ref={ref}
      className={`project-card transition-all duration-1000 ${
        isInView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-12'
      }`}
      style={{ transitionDelay: `${delay}s` }}
    >
      <div className="project-image-wrapper">
        <Image
          src={project.image}
          alt={project.name}
          fill
          className="project-image"
          sizes="100vw"
        />
        
        <div className="project-overlay">
          <div className="project-top">
            <span className="project-coords whitespace-pre-line">{project.coords}</span>
            <span className="project-location">{project.location}, {project.year}</span>
          </div>
          
          <div className="project-bottom">
            <div className="project-architect">
              <Image
                src={project.architectImage}
                alt={project.architect}
                width={36}
                height={36}
                className="project-architect-avatar"
              />
              <span className="project-architect-text">
                {project.prefix} {project.architect}
              </span>
            </div>
            
            <div className="project-info">
              <h3 className="project-name whitespace-pre-line">{project.name}</h3>
              <p className="project-description">{project.description}</p>
            </div>
          </div>
        </div>
      </div>
    </article>
  )
}
