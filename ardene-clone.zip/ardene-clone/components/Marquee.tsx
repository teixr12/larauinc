'use client'

export default function Marquee() {
  const items = ['timeless', 'french heritage', 'elegant']
  
  return (
    <div className="marquee-section">
      <div className="marquee-track">
        {[...Array(8)].map((_, setIndex) => (
          <div className="marquee-content" key={setIndex}>
            {items.map((text, i) => (
              <div className="marquee-item" key={`${setIndex}-${i}`}>
                <span className="marquee-star">✺</span>
                <span className="marquee-text">{text}</span>
              </div>
            ))}
          </div>
        ))}
      </div>
    </div>
  )
}
