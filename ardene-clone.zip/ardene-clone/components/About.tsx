'use client'

import Image from 'next/image'
import { useInView } from './useInView'
import SunIcon from './SunIcon'

export default function About() {
  const { ref, isInView } = useInView({ threshold: 0.2 })

  return (
    <section className="about-section" id="about" ref={ref}>
      {/* Left Column */}
      <div className="about-left">
        <h2 
          className={`about-title transition-all duration-1000 ${
            isInView ? 'opacity-100' : 'opacity-0'
          }`}
          style={{
            clipPath: isInView ? 'inset(0 0% 0 0)' : 'inset(0 100% 0 0)',
            transition: 'clip-path 1s cubic-bezier(0.77, 0, 0.175, 1)',
          }}
        >
          about
        </h2>
        
        <p 
          className={`about-text transition-all duration-700 ${
            isInView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
          }`}
          style={{ transitionDelay: '0.2s' }}
        >
          at ardène, we create boutique residences across france, defined by open space, natural light, and the elegance of simplicity. each home reflects french heritage and a timeless spirit of refined living
        </p>
        
        <div 
          className={`about-meta transition-all duration-700 ${
            isInView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
          }`}
          style={{ transitionDelay: '0.4s' }}
        >
          <SunIcon size={24} color="#121212" />
          <span className="about-since">Since 2004</span>
        </div>
        
        <a 
          href="#residences" 
          className={`about-btn transition-all duration-700 ${
            isInView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
          }`}
          style={{ transitionDelay: '0.5s' }}
        >
          Residences
        </a>
      </div>

      {/* Right Column */}
      <div className="about-right relative">
        <div 
          className={`relative transition-all duration-1000 ${
            isInView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-12'
          }`}
          style={{ transitionDelay: '0.2s' }}
        >
          <Image
            src="https://framerusercontent.com/images/2ukGpTC63zS9rQcSO51cj8u7TQM.png"
            alt="Woman in light suit"
            width={480}
            height={600}
            className="w-full h-auto object-cover"
          />
          
          {/* Founder Card */}
          <div 
            className={`founder-card transition-all duration-700 ${
              isInView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
            }`}
            style={{ transitionDelay: '0.6s' }}
          >
            <Image
              src="https://framerusercontent.com/images/MvnjtsxNXuJzLQYqzKe8Xm7KRw4.png"
              alt="Juliette Ardène"
              width={64}
              height={64}
              className="founder-avatar"
            />
            <div>
              <p className="founder-signature">Juliette Ardène</p>
              <p className="founder-tagline">Understated luxury.</p>
              <p className="founder-name">Juliette Ardène</p>
            </div>
            <a href="#" className="text-[11px] text-[#666] ml-6 hover:text-[#121212] transition-colors">
              Let's talk
            </a>
          </div>
        </div>
      </div>
    </section>
  )
}
