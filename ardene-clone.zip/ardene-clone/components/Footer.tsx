'use client'

import { LargeSunIcon } from './SunIcon'

export default function Footer() {
  return (
    <footer className="footer">
      <div className="footer-main">
        {/* Brand Column */}
        <div>
          <h3 className="footer-brand">ardène</h3>
          <p className="footer-tagline">
            boutique residences across france —<br />
            understated, timeless, refined
          </p>
          <div className="footer-location">
            <p className="footer-address">Ardène · Provence, France</p>
            <p className="footer-coords">43.7031° N, 5.4500° E</p>
            <a href="mailto:hello@tmpl.digital" className="footer-email">
              Hello@tmpl.digital
            </a>
          </div>
        </div>

        {/* Navigation Links */}
        <div className="footer-column">
          <a href="#about" className="footer-link underline">About</a>
          <a href="#residences" className="footer-link underline">Projects</a>
        </div>

        {/* Social Links */}
        <div className="footer-column">
          <a href="#" className="footer-link accent">X/Twitter</a>
          <a href="#" className="footer-link accent">Instagram</a>
          <a href="#" className="footer-link accent">Framer</a>
        </div>

        {/* Empty column for spacing */}
        <div className="footer-column" />
      </div>

      {/* Large Logo */}
      <div className="footer-logo-section">
        <LargeSunIcon size={180} color="#121212" />
        <span className="footer-large-text">ardène</span>
      </div>
    </footer>
  )
}
