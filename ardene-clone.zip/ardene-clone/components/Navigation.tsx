'use client'

import Link from 'next/link'
import SunIcon from './SunIcon'

export default function Navigation() {
  return (
    <nav className="nav">
      {/* Left - Links */}
      <div className="nav-left flex items-center gap-8">
        <Link href="#residences" className="nav-link flex items-center">
          Projects
          <span className="nav-badge">4</span>
        </Link>
        <Link href="#about" className="nav-link">
          About
        </Link>
      </div>

      {/* Center - Logo */}
      <div className="absolute left-1/2 -translate-x-1/2 flex items-center gap-2">
        <Link href="/" className="nav-logo">
          ardène
          <SunIcon size={20} color="white" />
        </Link>
      </div>

      {/* Right - Social & CTA */}
      <div className="nav-right flex items-center gap-6">
        <div className="nav-social flex items-center gap-4">
          <a href="#" className="text-white/70 hover:text-white transition-colors text-sm">𝕏</a>
          <a href="#" className="text-white/70 hover:text-white transition-colors text-sm">✕</a>
          <a href="#" className="text-white/70 hover:text-white transition-colors text-sm">◎</a>
        </div>
        <a href="#" className="nav-cta">
          Buy Template →
        </a>
      </div>
    </nav>
  )
}
