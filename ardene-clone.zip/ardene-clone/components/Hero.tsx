'use client'

import { useInView } from './useInView'
import Image from 'next/image'

export default function Hero() {
  const { ref, isInView } = useInView({ threshold: 0.1 })

  return (
    <section className="hero" ref={ref}>
      <div className="hero-image-container">
        <Image
          src="https://framerusercontent.com/images/0WVmIwuuJVFtVPeCd8xKkFVjp8I.png"
          alt="French countryside through villa"
          fill
          priority
          className="hero-image object-cover"
          sizes="100vw"
        />
        
        {/* Content overlay */}
        <div className="hero-content">
          <p 
            className={`hero-tagline transition-all duration-700 ${
              isInView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
            }`}
            style={{ transitionDelay: '0.3s' }}
          >
            creating timeless<br />residences in france
          </p>
          <h1 
            className={`hero-title transition-all duration-1000 ${
              isInView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-12'
            }`}
            style={{ transitionDelay: '0.5s' }}
          >
            ardène
          </h1>
        </div>
      </div>
    </section>
  )
}
