'use client'

interface SunIconProps {
  size?: number
  color?: string
  className?: string
}

export default function SunIcon({ size = 24, color = 'currentColor', className = '' }: SunIconProps) {
  const rays = 16
  const innerRadius = size * 0.12
  const outerRadius = size * 0.45
  const center = size / 2

  return (
    <svg 
      width={size} 
      height={size} 
      viewBox={`0 0 ${size} ${size}`} 
      fill="none" 
      className={className}
    >
      {/* Center circle */}
      <circle 
        cx={center} 
        cy={center} 
        r={innerRadius} 
        fill={color} 
      />
      
      {/* Rays */}
      {[...Array(rays)].map((_, i) => {
        const angle = (i * (360 / rays)) * (Math.PI / 180)
        const x1 = center + Math.cos(angle) * (innerRadius + 2)
        const y1 = center + Math.sin(angle) * (innerRadius + 2)
        const x2 = center + Math.cos(angle) * outerRadius
        const y2 = center + Math.sin(angle) * outerRadius
        
        return (
          <line
            key={i}
            x1={x1}
            y1={y1}
            x2={x2}
            y2={y2}
            stroke={color}
            strokeWidth={size * 0.04}
            strokeLinecap="round"
          />
        )
      })}
    </svg>
  )
}

// Large version for footer
export function LargeSunIcon({ size = 180, color = 'currentColor', className = '' }: SunIconProps) {
  const rays = 24
  const innerRadius = size * 0.08
  const outerRadius = size * 0.48
  const center = size / 2

  return (
    <svg 
      width={size} 
      height={size} 
      viewBox={`0 0 ${size} ${size}`} 
      fill="none" 
      className={className}
    >
      {/* Center circle */}
      <circle 
        cx={center} 
        cy={center} 
        r={innerRadius} 
        fill={color} 
      />
      
      {/* Rays */}
      {[...Array(rays)].map((_, i) => {
        const angle = (i * (360 / rays)) * (Math.PI / 180)
        const x1 = center + Math.cos(angle) * (innerRadius + 4)
        const y1 = center + Math.sin(angle) * (innerRadius + 4)
        const x2 = center + Math.cos(angle) * outerRadius
        const y2 = center + Math.sin(angle) * outerRadius
        
        return (
          <line
            key={i}
            x1={x1}
            y1={y1}
            x2={x2}
            y2={y2}
            stroke={color}
            strokeWidth={size * 0.012}
            strokeLinecap="round"
          />
        )
      })}
    </svg>
  )
}
