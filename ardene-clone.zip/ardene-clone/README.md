# Ardène Clone

A pixel-perfect recreation of the [Ardène Framer Template](https://ardene.framer.website/) built with Next.js 14, TypeScript, and Tailwind CSS.

![Ardène Preview](https://framerusercontent.com/images/0WVmIwuuJVFtVPeCd8xKkFVjp8I.png)

## Features

- 🎨 **Pixel-perfect design** - Exact recreation of the original Framer template
- ⚡ **Next.js 14** - Latest App Router with Server Components
- 📱 **Fully responsive** - Works on all devices
- 🎭 **Smooth animations** - Scroll-triggered animations and hover effects
- 🖼️ **Optimized images** - Next.js Image component for performance
- 🎯 **TypeScript** - Full type safety
- 💨 **Tailwind CSS** - Utility-first styling

## Tech Stack

- [Next.js 14](https://nextjs.org/)
- [React 18](https://reactjs.org/)
- [TypeScript](https://www.typescriptlang.org/)
- [Tailwind CSS](https://tailwindcss.com/)
- [Framer Motion](https://www.framer.com/motion/) (optional animations)

## Getting Started

### Prerequisites

- Node.js 18+ 
- npm or yarn

### Installation

1. Clone the repository:
```bash
git clone https://github.com/your-username/ardene-clone.git
cd ardene-clone
```

2. Install dependencies:
```bash
npm install
# or
yarn install
```

3. Run the development server:
```bash
npm run dev
# or
yarn dev
```

4. Open [http://localhost:3000](http://localhost:3000) in your browser.

## Deploy on Vercel

The easiest way to deploy this app is using [Vercel](https://vercel.com):

[![Deploy with Vercel](https://vercel.com/button)](https://vercel.com/new/clone?repository-url=https://github.com/your-username/ardene-clone)

Or deploy manually:

1. Push your code to GitHub
2. Import the repository on [Vercel](https://vercel.com/new)
3. Vercel will automatically detect Next.js and configure the build settings
4. Click "Deploy"

## Project Structure

```
ardene-clone/
├── app/
│   ├── globals.css      # Global styles
│   ├── layout.tsx       # Root layout
│   └── page.tsx         # Home page
├── components/
│   ├── Navigation.tsx   # Header navigation
│   ├── Hero.tsx         # Hero section
│   ├── About.tsx        # About section
│   ├── Marquee.tsx      # Scrolling marquee
│   ├── Residences.tsx   # Projects/Residences section
│   ├── Heritage.tsx     # Heritage grid section
│   ├── Footer.tsx       # Footer section
│   ├── SunIcon.tsx      # Custom sun/star icon
│   └── useInView.tsx    # Intersection Observer hook
├── public/              # Static assets
├── next.config.js       # Next.js configuration
├── tailwind.config.js   # Tailwind configuration
├── tsconfig.json        # TypeScript configuration
└── package.json         # Dependencies
```

## Customization

### Colors

Edit the CSS variables in `app/globals.css`:

```css
:root {
  --color-cream: #F8F0DD;
  --color-dark: #121212;
  --color-accent: #C4956A;
}
```

### Fonts

The project uses:
- **Inter** - For headings and body text
- **DM Mono** - For coordinates and monospace text

### Images

All images are loaded from Framer's CDN. To use your own images, replace the URLs in the component files.

## License

This project is for educational purposes only. The original design belongs to [tmpl.digital](https://tmpl.digital/).

## Credits

- Original design: [Ardène Template](https://ardene.framer.website/) by [tmpl.digital](https://tmpl.digital/)
- Built with: [Next.js](https://nextjs.org/)
