import Navigation from '@/components/Navigation'
import Hero from '@/components/Hero'
import About from '@/components/About'
import Marquee from '@/components/Marquee'
import Residences from '@/components/Residences'
import Heritage from '@/components/Heritage'
import Footer from '@/components/Footer'

export default function Home() {
  return (
    <main>
      <Navigation />
      <Hero />
      <About />
      <Marquee />
      <Residences />
      <Heritage />
      <Footer />
    </main>
  )
}
