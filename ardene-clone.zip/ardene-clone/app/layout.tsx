import type { Metadata } from 'next'
import { Inter } from 'next/font/google'
import './globals.css'

const inter = Inter({ 
  subsets: ['latin'],
  variable: '--font-inter',
  display: 'swap',
})

export const metadata: Metadata = {
  title: 'Ardène — Real Estate & Architecture Template',
  description: 'Creating timeless residences in France. Boutique residences defined by open space, natural light, and the elegance of simplicity.',
  keywords: ['architecture', 'real estate', 'france', 'luxury homes', 'residences'],
  openGraph: {
    title: 'Ardène — Real Estate & Architecture Template',
    description: 'Creating timeless residences in France',
    type: 'website',
  },
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en" className={inter.variable}>
      <body>{children}</body>
    </html>
  )
}
